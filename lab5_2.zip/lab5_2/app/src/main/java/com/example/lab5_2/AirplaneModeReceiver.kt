package com.example.lab5_2

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Log
import android.widget.TextView

class AirplaneModeReceiver(private val textView: TextView?) : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_AIRPLANE_MODE_CHANGED) {
            val isOn = Settings.Global.getInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON, 0
            ) != 0

            val status = if (isOn) "Авіарежим увімкнено" else "Авіарежим вимкнено"
            textView?.text = status
            Log.d("AirplaneReceiver", status)
        }
    }
}
