package com.example.lab5_2

import android.content.IntentFilter
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent

class MainActivity : AppCompatActivity() {

    private lateinit var powerReceiver: PowerReceiver
    private lateinit var airplaneModeReceiver: AirplaneModeReceiver
    private lateinit var airplaneText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        airplaneText = findViewById(R.id.airplaneStatus)
        powerReceiver = PowerReceiver()
        airplaneModeReceiver = AirplaneModeReceiver(airplaneText)
    }

    override fun onStart() {
        super.onStart()

        // Динамічна реєстрація зарядного приймача
        val powerFilter = IntentFilter(Intent.ACTION_POWER_CONNECTED)
        registerReceiver(powerReceiver, powerFilter)

        // Динамічна реєстрація авіарежиму
        val airplaneFilter = IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        registerReceiver(airplaneModeReceiver, airplaneFilter)
    }

    override fun onStop() {
        super.onStop()
        unregisterReceiver(powerReceiver)
        unregisterReceiver(airplaneModeReceiver)
    }
}
