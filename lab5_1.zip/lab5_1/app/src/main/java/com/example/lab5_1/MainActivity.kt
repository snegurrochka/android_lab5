package com.example.lab5_1

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Random

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView //щоб пізніше привязати до елемента інтерфейсу

    //функція що генерує випадковий колір
    private fun randomColor(): Int {
        val rnd = Random()
        //дає випадкове число від 0 до 255 для RGB
        return Color.rgb(rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256))
    }

    //створює список з елементів, кожному задає випадкове число та колір
    private fun generateItems(count: Int): List<GridItem> {
        return List(count) {
            GridItem(
                number = (1..99).random(),
                color = randomColor()
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 3)

        // створюємо 30 елементів
        val items = generateItems(30)
        val adapter = GridAdapter(items) { item ->
            showNumberDialog(item.number)
        }
        recyclerView.adapter = adapter
    }

    //функція яка викликається при натисканні на елемент
    //створює діалогове вікно із заголовком Натиснуто та числом елемента
    private fun showNumberDialog(number: Int) {
        AlertDialog.Builder(this)
            .setTitle("Натиснуто")
            .setMessage("Значення: $number")
            .setPositiveButton("OK", null)
            .show()
    }
}
