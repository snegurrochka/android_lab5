package com.example.lab5_1

//кожен елемент має свій колір та число
data class GridItem(
    val number: Int,
    val color: Int
)
